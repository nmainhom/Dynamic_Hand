"""Neuro-symbolic model components."""

